#include "nodo.h"
#include <iostream>

using namespace std;

class Arbin
{
    private:
        Nodo *raiz;
        Nodo *Insertar(Nodo*,Nodo*);
        Nodo *Borrar(Nodo*, int);
        int  getInfo_der(Nodo*);
        void preOrden(Nodo*);
        void inOrden(Nodo*);
        void postOrden(Nodo*);
    public:
        Arbin();
        void Crear(Nodo*);
        void Recorridos(int);
        void Eliminar(int);
        ~Arbin();
};

Arbin::Arbin(){
    raiz = NULL;
}

Nodo* Arbin::Insertar(Nodo *p, Nodo *q){
    if(p == NULL){
        p = q;
    }
    else{
        if(q->info < p->info){
            p->Llink = Insertar(p->Llink,q);
        }
        else{
            p->Rlink = Insertar(p->Rlink,q);
        }
    }
    
    return p;
}

void Arbin::Crear(Nodo *q)
{
    raiz = Insertar(raiz,q);
}

void Arbin::preOrden(Nodo *p){
    if(p != NULL){
        cout << p->info << ", ";
        preOrden(p->Llink);
        preOrden(p->Rlink);
    }
}

void Arbin::inOrden(Nodo *p){
    if(p != NULL){        
        inOrden(p->Llink);
        cout << p->info << ", ";
        inOrden(p->Rlink);
    }
}

void Arbin::postOrden(Nodo *p){
    if(p != NULL){
        cout << p->info << ", ";
        postOrden(p->Llink);
        postOrden(p->Rlink);
    }
}

void Arbin::Recorridos(int tipo){
    switch(tipo){
        case 1:
            preOrden(raiz);
        break;
        
        case 2:
            inOrden(raiz);
        break;
        
        case 3:
            postOrden(raiz);
        break;
	
        default:
	  cout<<"Error! opcion invalida"<<endl;
	  break;
    }
}

int Arbin::getInfo_der(Nodo *q){
    if(q->Rlink == NULL){
        return q->info;
    }
    else{
        return getInfo_der(q->Rlink);
    }
}

Nodo* Arbin::Borrar(Nodo *p, int info){
    Nodo *q;
    
    if(p != NULL){
        if(p->info == info){
            if(p->Llink == NULL && p->Rlink == NULL){
                delete p;
                p = NULL;
            }
            else{
                if(p->Llink == NULL && p->Rlink != NULL){
                    q = p->Rlink;
                    delete p;
                    p = q;
                }
                else{
                    info = getInfo_der(p->Llink);
                    p->info = info;
                    p = p->Llink;
                    p->Rlink = Borrar(p->Rlink, info);
                }
            }
        }
        else{
            if(info < p->info){
                p->Llink = Borrar(p->Llink, info);
            }
            else{
                p->Rlink = Borrar(p->Rlink, info);
            }
        }
    }
    
    return p;
}

void Arbin::Eliminar(int info){
    raiz = Borrar(raiz, info);
}

Arbin::~Arbin(){}






